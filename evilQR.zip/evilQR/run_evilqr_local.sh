#!/usr/bin/env bash
set -euo pipefail
# Simple runner: builds (if build.sh exists) and runs the server binary with -d server/www
if [ -f server/build.sh ]; then
  (cd server && chmod +x build.sh && ./build.sh) || echo "[run] build.sh returned non-zero"
fi
if [ ! -f server/build/evilqr-server ]; then
  echo "[run] server/build/evilqr-server not found. Build first or check build logs."
  exit 1
fi
mkdir -p server/www
cp -r server/templates/* server/www/ || true
echo "[run] Starting evilqr-server -d server/www (logs -> evilqr_server.log)"
nohup server/build/evilqr-server -d server/www > evilqr_server.log 2>&1 &
sleep 1
echo "[run] PID: $(pgrep -f evilqr-server || echo 'not running')"
echo "[run] tail -n 60 evilqr_server.log"
tail -n 60 evilqr_server.log || true
